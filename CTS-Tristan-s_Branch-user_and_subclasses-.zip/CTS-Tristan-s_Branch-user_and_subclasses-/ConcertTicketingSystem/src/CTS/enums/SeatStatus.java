package CTS.enums;

public enum SeatStatus {
    AVAILABLE,
    HELD,
    SOLD,
    ADMIN_HELD

}
