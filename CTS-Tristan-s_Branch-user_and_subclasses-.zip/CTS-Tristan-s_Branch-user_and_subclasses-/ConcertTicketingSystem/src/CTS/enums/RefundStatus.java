package CTS.enums;

public enum RefundStatus {
    PENDING,
    APPROVED,
    DENIED

}
