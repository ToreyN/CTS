package CTS.enums;

public enum PaymentStatus {
    PENDING,
    SUCCESS,
    FAILED    

}
