package CTS.enums;

public enum EventStatus {
    DRAFT,
    PUBLISHED,
    CANCELED

}
