package CTS.enums;

public enum OrderStatus {
    PENDING,
    CONFIRMED,
    REFUNDED,
    CANCELED

}
