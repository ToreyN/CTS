package CTS.enums;

public enum HoldStatus {
    ACTIVE,
    EXPIRED,
    CONVERTED

}
