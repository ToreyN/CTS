package CTS.enums;

public enum PaymentType {
    AUTH,
    CHARGE,
    REFUND

}
